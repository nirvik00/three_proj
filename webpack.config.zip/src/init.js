import  * as THREE from 'three'
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls"

var scene, camera, renderer, controls, div3d, raycaster;

function init3d(){
    div3d=document.createElement("div3d");

    raycaster=new THREE.Raycaster();

    scene=new THREE.Scene();
    scene.background=new THREE.Color(0xcccfff);

    camera=new THREE.PerspectiveCamera(45, window.innerWidth/ window.innerHeight, 0.1, 100000);
    camera.up=new THREE.Vector3(0,0,1);
    camera.lookAt(new THREE.Vector3(0,0,0));
    camera.position.set(50,50,50);

    renderer=new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    div3d.appendChild(renderer.domElement);
    document.body.appendChild(div3d);

    controls=new OrbitControls(camera, renderer.domElement);
    controls.addEventListener("change", render);

    var ax=new THREE.AxesHelper(10);
    scene.add(ax);
    render();
}

function render(){
    renderer.render(scene, camera);
}

export default init3d;